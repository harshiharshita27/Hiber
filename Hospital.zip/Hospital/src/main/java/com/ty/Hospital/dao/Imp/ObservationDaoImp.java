package com.ty.Hospital.dao.Imp;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.ty.Hospital.dao.ObservationDao;
import com.ty.Hospital.dto.Encounter;
import com.ty.Hospital.dto.MedOrder;
import com.ty.Hospital.dto.Observation;

public class ObservationDaoImp implements ObservationDao {

	public Observation saveObservation(int eid, Observation observation) {
		
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Encounter encounter= emEntityManager.find(Encounter.class, eid);
		if(encounter!=null) {
			etEntityTransaction.begin();
			emEntityManager.persist(observation);
			etEntityTransaction.commit();
		return observation;}
		else
		{
			return null;
		}
	}

	public Observation getObservationId(int oid) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Observation observation=emEntityManager.find(Observation.class, oid);
		return observation;
	}

	public boolean deleteObservationById(int oid) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Observation observation=emEntityManager.find(Observation.class, oid);
		if(observation!=null) {
			etEntityTransaction.begin();
			emEntityManager.remove(observation);
			etEntityTransaction.commit();
			return true;
		}
		else {
		return false;}
	}

	public Observation updateObservationById(int oid, Observation observation) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Observation observation1=emEntityManager.find(Observation.class, oid);
		if(observation1!=null) {
		observation1.setDname(observation.getDname());
		observation1.setReasonforobservation(observation.getReasonforobservation());
			etEntityTransaction.begin();
			emEntityManager.remove(observation1);
			etEntityTransaction.commit();
			return observation1;}
		else {
		return null;}
	}

	public List<Observation> getAllObservation() {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		Query query=emEntityManager.createNamedQuery("select o from Observation m");
		List<Observation> observations=query.getResultList();
		return observations;
	}

}
