package com.ty.Hospital.dao;

import java.util.List;

import com.ty.Hospital.dto.Item;

public interface ItemDao {
	public Item saveItem(int mid,Item item);

	public Item  getItemById(int iId);

	public boolean deleteItemById(int iId);

	public Item updateItemById(int iId,Item item);
	
	public List<Item> getAllItem();

}