package com.ty.Hospital.Service;

import com.ty.Hospital.dao.Imp.HospitalDaoImp;
import com.ty.Hospital.dto.Hospital;

public class HospitalService {
public void SaveHospital(Hospital hospital){
	HospitalDaoImp hospitalDaoImp = new HospitalDaoImp();
	Hospital hospital1 =hospitalDaoImp.SaveHospital(hospital) ;
	if(hospital1!=null) {
		System.out.println("data save");
	}
	else {
		System.out.println("unfortunally data not saved");
	}
}

public Hospital getHospital(int hid) {
	HospitalDaoImp hospitalDaoImp = new HospitalDaoImp();
	Hospital hospital1 =hospitalDaoImp.getHospitalById(hid);
	if(hospital1!=null) {
		return hospital1;
	}
	else {
		return null;}
}

public void deleteHospital(int hid) {
	HospitalDaoImp hospitalDaoImp = new HospitalDaoImp();
	boolean flag =hospitalDaoImp.deleteHospitalById(hid) ;
	if(flag) {
		System.out.println("data delete");
	}
	else {
		System.out.println("data not delete");
	}
}


public Hospital updateHospitalById(int hid, Hospital hospital) {
	HospitalDaoImp hospitalDaoImp = new HospitalDaoImp();
	Hospital hospital1 =hospitalDaoImp.updateHospitalById(hid, hospital) ;
	if(hospital1!=null) {
		return hospital1;
	}
	else {
		return null;
	}
	
}











}









