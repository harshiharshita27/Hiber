package com.ty.Hospital.Service;

import java.util.List;

import com.ty.Hospital.dao.Imp.AddressDaoImp;

import com.ty.Hospital.dto.Address;


public class AddressService {
	public void saveAddress(int bid, Address address) {
		AddressDaoImp addressDaoImp = new AddressDaoImp();
		Address address1 = addressDaoImp.saveAddress(bid, address);
		if(address1!=null) {
			System.out.println("save data");}
			else {
				System.out.println("not save data");;
			}
	}
	
	public Address getAddressById(int aid) {
		AddressDaoImp addressDaoImp = new AddressDaoImp();
		Address address1 = addressDaoImp.getAddressById(aid);
		if(address1!=null) {
			return address1;}
			else {
				return null;
			}
	}
	
	public void deleteAdressById(int aid) {
		AddressDaoImp addressDaoImp = new AddressDaoImp();
		boolean flag= addressDaoImp.deleteAdressById(aid);
		if(flag) {
			System.out.println("delete data");
		}
		else {
			System.out.println("not delete");
		}
	}
	
	
	public Address updateAddressById(int aid, Address address) {
		AddressDaoImp addressDaoImp = new AddressDaoImp();
		Address address1 = addressDaoImp.updateAddressById(aid, address);
		if(address1!=null) {
			return address1;}
			else {
				return null;
			}	
	}
	
	public List<Address> getAllAdress() {
		AddressDaoImp addressDaoImp = new AddressDaoImp();
		List<Address> addresses= addressDaoImp.getAllAdress();
		if(addresses.size()>0) {
		return addresses;
	}
	else 
		return null;
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
