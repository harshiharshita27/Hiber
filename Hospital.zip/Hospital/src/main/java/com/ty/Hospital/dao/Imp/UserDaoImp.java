package com.ty.Hospital.dao.Imp;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.ty.Hospital.dao.UserDao;
import com.ty.Hospital.dto.User;

public class UserDaoImp implements UserDao{

	public User saveUser(User user) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		etEntityTransaction.begin();
		emEntityManager.persist(user);
		etEntityTransaction.commit();
		return user;
	}

	public User getUserById(int uid) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		User user=emEntityManager.find(User.class, uid);
		return user;
	}

	public boolean deleteUserById(int uid) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		User user=emEntityManager.find(User.class, uid);
		if(user!=null) {
			etEntityTransaction.begin();
			emEntityManager.remove(user);
			etEntityTransaction.commit();
			return true;
		}
		else {
		return false;}
	}

	public User updateUserById(int uid, User user) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
	User user1=emEntityManager.find(User.class, uid);
		if(user1!=null) {
			etEntityTransaction.begin();
			emEntityManager.remove(user1);
			etEntityTransaction.commit();
			return user1;}
		else {
		return null;}
	}

	public List<User> getAllUser() {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		Query query=emEntityManager.createNamedQuery("select u from User u");
		List<User> users=query.getResultList();
		return users;
	}

	public User getUserByName(String name) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		User user=emEntityManager.find(User.class, "name");
		return user;
	}

	public User getUserByRole(String role) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		User user=emEntityManager.find(User.class, "role");
		return user;
	}

}
