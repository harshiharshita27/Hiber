package com.ty.Hospital.dao.Imp;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.ty.Hospital.dao.HospitalDao;
import com.ty.Hospital.dto.Hospital;

public class HospitalDaoImp  implements HospitalDao {

	public Hospital SaveHospital(Hospital hospital) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		etEntityTransaction.begin();
		emEntityManager.persist(hospital);
		etEntityTransaction.commit();
		return hospital;
	}

	public Hospital getHospitalById(int hid) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		Hospital hospital=emEntityManager.find(Hospital.class, hid);
		return hospital;
	}

	public boolean deleteHospitalById(int hid) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Hospital hospital=emEntityManager.find(Hospital.class, hid);
		if(hospital!=null) {
			etEntityTransaction.begin();
			emEntityManager.remove(hospital);
			etEntityTransaction.commit();
			return true;
		}
		else {
		return false;}
		
	}

	public Hospital updateHospitalById(int hid, Hospital hospital) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Hospital hospital1=emEntityManager.find(Hospital.class, hid);
		if(hospital!=null) {
			hospital1.setName(hospital.getName());
			hospital1.setWebsite(hospital.getWebsite());
			etEntityTransaction.begin();
			emEntityManager.merge(hospital1);
			etEntityTransaction.commit();
		return hospital1;}
		else {
			return null;
		}
	}

}
