package com.ty.Hospital.Service;

import java.util.List;

import com.ty.Hospital.dao.Imp.ItemDaoImp;
import com.ty.Hospital.dto.Item;

public class ItemService {
	public void saveItem(int mid, Item item) {
		ItemDaoImp imItemDaoImp = new ItemDaoImp();
		Item item1=imItemDaoImp.saveItem(mid, item);

		if(item1!=null) {
			System.out.println("save data");}
			else {
				System.out.println("not save data");
			}
	}
	public Item getItemById(int Iid) {
		ItemDaoImp imItemDaoImp = new ItemDaoImp();
		Item item1=imItemDaoImp.getItemById(Iid);

		if(item1!=null) {
			return item1;}
			else {
				return null;
			}
	}
	
	public void deleteItemById(int Iid) {
		ItemDaoImp imItemDaoImp = new ItemDaoImp();
		boolean flag=imItemDaoImp.deleteItemById(Iid);
		if(flag) {
			System.out.println("delete data");
		}
		else {
			System.out.println("not delete");
		}
	}
	
	public Item updateItemById(int Iid, Item item) {
		ItemDaoImp imItemDaoImp = new ItemDaoImp();
		Item item1=imItemDaoImp.updateItemById(Iid, item);

		if(item1!=null) {
			return item1;}
			else {
				return null;
			}
	}
	
	public List<Item> getAllItem(){
		ItemDaoImp imItemDaoImp = new ItemDaoImp();
		List<Item> items=imItemDaoImp.getAllItem();
		if(items.size()>0) {
	return items;
	}
		else {
			return null;
		}
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
