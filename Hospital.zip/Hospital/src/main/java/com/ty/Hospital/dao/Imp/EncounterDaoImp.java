package com.ty.Hospital.dao.Imp;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.ty.Hospital.dao.EncounterDao;
import com.ty.Hospital.dto.Branch;
import com.ty.Hospital.dto.Encounter;

public class EncounterDaoImp implements EncounterDao{

	public Encounter saveEncounter(int bid, Encounter encounter) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Branch branch = emEntityManager.find(Branch.class, bid);
		if(branch!=null) {
			etEntityTransaction.begin();
			emEntityManager.persist(encounter);
			etEntityTransaction.commit();
		return encounter;}
		else
		{
			return null;
		}
		
	}

	public Encounter getEncounterById(int eid) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Encounter encounter=emEntityManager.find(Encounter.class, eid);
		return encounter;
	}

	public boolean deleteEncounterById(int eid) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Encounter encounter=emEntityManager.find(Encounter.class, eid);
		if(encounter!=null) {
			etEntityTransaction.begin();
			emEntityManager.remove(encounter);
			etEntityTransaction.commit();
			return true;
		}
		else {
		return false;}
	}

	public Encounter updateEncounterById(int eid, Encounter encounter) {
		
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Encounter encounter1=emEntityManager.find(Encounter.class, eid);
		if(encounter1!=null) {
			encounter1.setDateofdischarge(encounter.getDateofdischarge());
			encounter1.setDateofjoin(encounter.getDateofjoin());
			etEntityTransaction.begin();
			emEntityManager.merge(encounter1);
			etEntityTransaction.commit();
			return encounter1;
		}
		else {
		return null;}
	}

	public List<Encounter> getAllEncounter() {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Query query=emEntityManager.createNamedQuery("select e from Encounter e");
		List<Encounter> encounters=query.getResultList();
		return encounters;
	}

}
