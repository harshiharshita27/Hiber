package com.ty.Hospital.Service;

import java.util.List;

import com.ty.Hospital.dao.Imp.PersonDaoImp;
import com.ty.Hospital.dto.Person;



public class PersonSerivce {
	public void savePerson(int eid, Person Person) {
		PersonDaoImp personDaoImp = new PersonDaoImp();
		Person person1 = personDaoImp.savePerson(eid, Person);
		if(person1!=null) {
			System.out.println("save data");
		}
		else {
			System.out.println("not save data");
		}
	}
	public Person getPersonById(int pid) {
		PersonDaoImp personDaoImp = new PersonDaoImp();
		Person person1 = personDaoImp.getPersonById(pid);
		if(person1!=null) {
			return person1;
		}
		else {
			return null;
		}
	}
	public void deletePersonById(int pid) {
		PersonDaoImp personDaoImp = new PersonDaoImp();
		boolean flag = personDaoImp.deletePersonById(pid);
		if(flag) {
			System.out.println("delete data");
		}
		else {
			System.out.println("not delete");
		}
	}
	public Person updatePersonById(int pid, Person person) {
		PersonDaoImp personDaoImp = new PersonDaoImp();
		Person person1 = personDaoImp.updatePersonById(pid, person);
		if(person1!=null) {
			return person1;
		}
		else {
			return null;
		}

	}
	
	public List<Person> getAllPerson(){
		PersonDaoImp personDaoImp = new PersonDaoImp();
		List<Person> persons = personDaoImp.getAllPerson();
		if(persons.size()>0) {
		return persons;
	}
	else
		return null;
}
	
	public List<Person> getPersonByGender(String gender){
		PersonDaoImp personDaoImp = new PersonDaoImp();
		List<Person> persons = personDaoImp.getPersonByGender(gender);
		if(persons.size()>0) {
			return persons;
		}
		else
			return null;
	}
	
	public List<Person> getPersonByPhno(long phno){
		PersonDaoImp personDaoImp = new PersonDaoImp();
		List<Person> persons = personDaoImp.getPersonByPhno(phno);
		if(persons.size()>0) {
			return persons;
		}
		else
			return null;
	}
	
	public List<Person> getPersonByAge(int age){
		PersonDaoImp personDaoImp = new PersonDaoImp();
		List<Person> persons = personDaoImp.getPersonByAge(age);
		if(persons.size()>0) {
			return persons;
		}
		else
			return null;
	}	
}
