package com.ty.Hospital.dao.Imp;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.ty.Hospital.dao.ItemDao;
import com.ty.Hospital.dto.Encounter;
import com.ty.Hospital.dto.Item;
import com.ty.Hospital.dto.MedOrder;

public class ItemDaoImp implements ItemDao {

	public Item saveItem(int mid, Item item) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Encounter encounter= emEntityManager.find(Encounter.class, mid);
		if(encounter!=null) {
			etEntityTransaction.begin();
			emEntityManager.persist(item);
			etEntityTransaction.commit();
		return item;}
		else
		{
			return null;
		}
	}

	public Item getItemById(int Iid) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Item item=emEntityManager.find(Item.class, Iid);
		return item;
	}

	public boolean deleteItemById(int Iid) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Item item=emEntityManager.find(Item.class, Iid);
		if(item!=null) {
			etEntityTransaction.begin();
			emEntityManager.remove(item);
			etEntityTransaction.commit();
			return true;
		}
		else {
		return false;}
	}
	
	public Item updateItemById(int Iid, Item item) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Item item1=emEntityManager.find(Item.class, Iid);
		if(item!=null) {
			item1.setName(item.getName());
		item1.setCost(item.getCost());
			etEntityTransaction.begin();
			emEntityManager.remove(item1);
			etEntityTransaction.commit();
			return item1;}
		else {
		return null;}
	}

	public List<Item> getAllItem() {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		Query query=emEntityManager.createNamedQuery("select i from Item i");
		List<Item> items=query.getResultList();
		return items;
	}

}
