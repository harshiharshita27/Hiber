package com.ty.Hospital.Service;

import java.util.List;


import com.ty.Hospital.dao.Imp.MedOrderDaoImp;
import com.ty.Hospital.dto.MedOrder;

public class MedOrderService {
	public void saveMedOrder(int eid, MedOrder medOrder) {
		MedOrderDaoImp medOrderDaoImp = new MedOrderDaoImp();
		MedOrder medOrder1=medOrderDaoImp.saveMedOrder(eid ,medOrder);
	
		if(medOrder1!=null) {
			System.out.println("save data");}
			else {
				System.out.println("not save data");
			}
	}
	
	public MedOrder getMedOrderById(int mid) {
		MedOrderDaoImp medOrderDaoImp = new MedOrderDaoImp();
		MedOrder medOrder1=medOrderDaoImp.getMedOrderById(mid);
	
		if(medOrder1!=null) {
			return medOrder1;}
			else {
				return null;
			}
	}
	public void deleteMedOrderById(int mid) {
		MedOrderDaoImp medOrderDaoImp = new MedOrderDaoImp();
		boolean flag=medOrderDaoImp.deleteMedOrderById(mid);
		if(flag) {
			System.out.println("delete data");
		}
		else {
			System.out.println("not delete");
		}
	}
		
	public MedOrder updateMedOrderById(int mid, MedOrder medOrder) {
			MedOrderDaoImp medOrderDaoImp = new MedOrderDaoImp();
			MedOrder medOrder1=medOrderDaoImp.updateMedOrderById(mid,medOrder);
			if(medOrder1!=null) {
				return medOrder1;}
				else {
					return null;
				}
		}
		
	public List<MedOrder> getAllMedOrder()	{
		MedOrderDaoImp medOrderDaoImp = new MedOrderDaoImp();
		List<MedOrder> medOrders=medOrderDaoImp.getAllMedOrder();
		if(medOrders.size()>0) {
		return medOrders;
	}
		else
			return null;
	}
	
	public MedOrder getMedOrderByDate(String date) {
		MedOrderDaoImp medOrderDaoImp = new MedOrderDaoImp();
		MedOrder medOrder1=medOrderDaoImp.getMedOrderByDate(date);
		if(medOrder1!=null) {
			return medOrder1;}
			else {
				return null;
			}
	}
		
	public MedOrder getMedOrderByDoctorName(String name) {
		MedOrderDaoImp medOrderDaoImp = new MedOrderDaoImp();
		MedOrder medOrder1=medOrderDaoImp.getMedOrderByDoctorName(name);
		if(medOrder1!=null) {
			return medOrder1;}
			else {
				return null;
			}
	}
		
}
	
	
	
	
	
	
	
