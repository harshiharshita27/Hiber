package com.ty.Hospital.dao;

import java.util.List;

import com.ty.Hospital.dto.Address;


public interface AddressDao {

	public Address saveAddress(int bid,Address  address);
	
	public Address getAddressById(int aid);
	
	public boolean deleteAdressById(int aid);
	
	public Address updateAddressById(int aid,Address address);
	
	public List<Address> getAllAdress();
}
