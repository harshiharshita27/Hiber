package com.ty.Hospital.Service;

import java.util.List;

import com.ty.Hospital.dao.Imp.ObservationDaoImp;
import com.ty.Hospital.dto.Observation;

public class ObservationService {
	public Observation saveObservation(int eid, Observation observation) {
		ObservationDaoImp observationDaoImp = new ObservationDaoImp();
		Observation observation1 = observationDaoImp.saveObservation(eid, observation);
		if(observation1!=null) {
			return observation1;
		}
		else {
			return null;
		}
	}
	
	public Observation getObservationId(int oid) {
		ObservationDaoImp observationDaoImp = new ObservationDaoImp();
		Observation observation1 = observationDaoImp.getObservationId(oid);
		if(observation1!=null) {
			return observation1;
		}
		else {
			return null;
		}
	}
	public void deleteObservationById(int oid) {
		ObservationDaoImp observationDaoImp = new ObservationDaoImp();
		boolean flag= observationDaoImp.deleteObservationById(oid);
		if(flag) {
			System.out.println("delete data");
		}
		else {
			System.out.println("not delete");
		}
	}
	public Observation updateObservationById(int oid, Observation observation) {
		ObservationDaoImp observationDaoImp = new ObservationDaoImp();
		Observation observation1 = observationDaoImp.updateObservationById(oid, observation);
		if(observation1!=null) {
			return observation1;
		}
		else {
			return null;
		}
	}
	
	public List<Observation> getAllObservation(){
		ObservationDaoImp observationDaoImp = new ObservationDaoImp();
		List<Observation> observations = observationDaoImp.getAllObservation();
		if(observations.size()>0) {
				return observations;}
		else
			return null;
	}
}
