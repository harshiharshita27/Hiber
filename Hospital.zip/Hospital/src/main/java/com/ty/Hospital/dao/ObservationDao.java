package com.ty.Hospital.dao;

import java.util.List;

import com.ty.Hospital.dto.Observation;

public interface ObservationDao {

	public Observation saveObservation(int eid,Observation observation);

	public Observation getObservationId(int oid);

	public boolean deleteObservationById(int oid);

	public Observation updateObservationById(int oid,Observation observation);

	public List<Observation> getAllObservation();
}