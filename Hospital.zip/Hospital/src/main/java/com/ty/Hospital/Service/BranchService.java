package com.ty.Hospital.Service;

import java.util.List;

import com.ty.Hospital.dao.Imp.BranchDaoImp;
import com.ty.Hospital.dto.Branch;

public class BranchService {
	public void saveBranch(int hid, Branch branch) {
		BranchDaoImp branchDaoImp = new BranchDaoImp();
		Branch branch1= branchDaoImp.saveBranch(hid, branch);
				if(branch1!=null) {
				System.out.println("save data");}
				else {
					System.out.println("not save data");;
				}
	}
	
	
	public Branch getBranchById(int bid) {
		BranchDaoImp branchDaoImp = new BranchDaoImp();
		Branch branch1= branchDaoImp.getBranchById(bid);
				if(branch1!=null) {
				return branch1;}
				else {
					return null;
				}
	}
	
	
	public void deleteBranchById(int bid) {
		BranchDaoImp branchDaoImp = new BranchDaoImp();
		boolean flag = branchDaoImp.deleteBranchById(bid);
		if(flag) {
			System.out.println("delete data");
		}
		else {
			System.out.println("not delete");
		}
		
	}
	
	
	public Branch updateBranchById(int bid, Branch branch) {
		BranchDaoImp branchDaoImp = new BranchDaoImp();
		Branch branch1= branchDaoImp.updateBranchById(bid, branch);
				if(branch1!=null) {
				return branch1;}
				else {
					return null;
				}
	}
	
	
	public List<Branch> getAllBranch(){
		BranchDaoImp branchDaoImp = new BranchDaoImp();
		List<Branch> branch1= branchDaoImp.getAllBranch();
		if(branch1.size()>0) {
			return branch1;
		}
		else {
			return null;
		}
		
	}
	
	}
