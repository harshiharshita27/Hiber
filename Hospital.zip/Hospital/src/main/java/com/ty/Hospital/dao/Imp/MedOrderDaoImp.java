package com.ty.Hospital.dao.Imp;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.ty.Hospital.dao.MedOrderDao;
import com.ty.Hospital.dto.Branch;
import com.ty.Hospital.dto.Encounter;
import com.ty.Hospital.dto.MedOrder;

public class MedOrderDaoImp  implements MedOrderDao{

	public MedOrder saveMedOrder(int eid, MedOrder medOrder) {
		
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Encounter encounter= emEntityManager.find(Encounter.class, eid);
		if(encounter!=null) {
			etEntityTransaction.begin();
			emEntityManager.persist(medOrder);
			etEntityTransaction.commit();
		return medOrder;}
		else
		{
			return null;
		}
	}

	public MedOrder getMedOrderById(int mid) {
		
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		MedOrder medOrder=emEntityManager.find(MedOrder.class, mid);
		return medOrder;
	}

	public boolean deleteMedOrderById(int mid) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		MedOrder medOrder=emEntityManager.find(MedOrder.class, mid);
		if(medOrder!=null) {
			etEntityTransaction.begin();
			emEntityManager.remove(medOrder);
			etEntityTransaction.commit();
			return true;
		}
		else {
		return false;}
	}

	public MedOrder updateMedOrderById(int mid, MedOrder medOrder) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		MedOrder medOrder1=emEntityManager.find(MedOrder.class, mid);
		if(medOrder1!=null) {
			medOrder1.setDname(medOrder.getDname());
		medOrder1.setTotal(medOrder.getMid());
			etEntityTransaction.begin();
			emEntityManager.remove(medOrder1);
			etEntityTransaction.commit();
			return medOrder1;}
		else {
		return null;}
	}

	public List<MedOrder> getAllMedOrder() {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		Query query=emEntityManager.createNamedQuery("select m from MedOrder m");
		List<MedOrder> medOrders=query.getResultList();
		return medOrders;
		
	}

	public MedOrder getMedOrderByDate(String date) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		MedOrder medOrder=emEntityManager.find(MedOrder.class, date);
		return medOrder;
	}

	public MedOrder getMedOrderByDoctorName(String name) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		MedOrder medOrder=emEntityManager.find(MedOrder.class, name);
		return medOrder;
	}

}
