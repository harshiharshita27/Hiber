package com.ty.Hospital.Controller;

import com.ty.Hospital.Service.HospitalService;
import com.ty.Hospital.dto.Hospital;

public class DeleteHospital {

	public static void main(String[] args) {
		Hospital hospital = new Hospital();
		HospitalService service = new HospitalService();
		service.deleteHospital(1);

	}

}
