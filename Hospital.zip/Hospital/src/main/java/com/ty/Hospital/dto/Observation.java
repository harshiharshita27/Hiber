package com.ty.Hospital.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Observation {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int oid;
	private String dname;
	private String reasonforobservation;
	@ManyToOne
	@JoinColumn
	private Encounter encounters1;
	public int getOid() {
		return oid;
	}
	public void setOid(int oid) {
		this.oid = oid;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getReasonforobservation() {
		return reasonforobservation;
	}
	public void setReasonforobservation(String reasonforobservation) {
		this.reasonforobservation = reasonforobservation;
	}
	public Encounter getEncounters1() {
		return encounters1;
	}
	public void setEncounters1(Encounter encounters1) {
		this.encounters1 = encounters1;
	}


}
