package com.ty.Hospital.Controller;

import com.ty.Hospital.Service.EncounterService;
import com.ty.Hospital.dto.Encounter;

public class SaveEncounter {

	public static void main(String[] args) {
		Encounter encounter = new Encounter();
		EncounterService service = new EncounterService();
		encounter.setDateofjoin("12 March");
		encounter.setDateofdischarge("15 march");
		service.saveEncounter(2, encounter);
		
	}

}
