package com.ty.Hospital.Controller;

import com.ty.Hospital.Service.HospitalService;
import com.ty.Hospital.dto.Hospital;

public class TestSaveHospital {

	public static void main(String[] args) {
		Hospital hospital = new Hospital();
		HospitalService service = new HospitalService();
		hospital.setName("Bapuji");
		hospital.setWebsite("www.bapuji.com");
		service.SaveHospital(hospital);
		
		Hospital hospital1 = new Hospital();
		HospitalService service1 = new HospitalService();
		hospital1.setName("apollo");
		hospital1.setWebsite("www.apollo.com");
		service1.SaveHospital(hospital1);

		
		Hospital hospital2 = new Hospital();
		HospitalService service2 = new HospitalService();
		hospital2.setName("OPD");
		hospital2.setWebsite("www.opd.com");
		service2.SaveHospital(hospital2);

		
		Hospital hospital3 = new Hospital();
		HospitalService service3 = new HospitalService();
		hospital3.setName("Helthcare");
		hospital3.setWebsite("www.health.com");
		service3.SaveHospital(hospital3);

		Hospital hospital4 = new Hospital();
		HospitalService service4 = new HospitalService();
		hospital4.setName("good health");
		hospital4.setWebsite("www.good.com");
		service4.SaveHospital(hospital4);


	}

}
