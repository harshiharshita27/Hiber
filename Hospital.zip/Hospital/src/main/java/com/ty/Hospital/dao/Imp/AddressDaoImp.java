package com.ty.Hospital.dao.Imp;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.ty.Hospital.dao.AddressDao;
import com.ty.Hospital.dto.Address;
import com.ty.Hospital.dto.Branch;

public class AddressDaoImp implements AddressDao {

	public Address saveAddress(int bid, Address address) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Branch branch = emEntityManager.find(Branch.class, bid);
		if(branch!=null) {
			etEntityTransaction.begin();
			emEntityManager.persist(address);
			etEntityTransaction.commit();
		return address;}
		else
		{
			return null;
		}
	}

	public Address getAddressById(int aid) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		Address address=emEntityManager.find(Address.class, aid);
		return address;
	}

	public boolean deleteAdressById(int aid) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Address address=emEntityManager.find(Address.class, aid);
		if(address!=null) {
			etEntityTransaction.begin();
			emEntityManager.remove(address);
			etEntityTransaction.commit();
			return true;
		}
		else {
		return false;}
	}

	public Address updateAddressById(int aid, Address address) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Address address1 =emEntityManager.find(Address.class, aid);
		if(address1!=null) {
			address1.setState(address.getState());
			address1.setStreet(address.getStreet());
			etEntityTransaction.begin();
			emEntityManager.merge(address);
			etEntityTransaction.commit();
			return address1;
			}
		else {
		
		return null;}
	}

	public List<Address> getAllAdress() {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		Query query=emEntityManager.createNamedQuery("select a from Address a");
		List<Address> addresses=query.getResultList();
		return addresses;
	}

}
