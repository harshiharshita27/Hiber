package com.ty.Hospital.dao.Imp;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.ty.Hospital.dao.PersonDao;
import com.ty.Hospital.dto.Encounter;
import com.ty.Hospital.dto.MedOrder;
import com.ty.Hospital.dto.Observation;
import com.ty.Hospital.dto.Person;

public class PersonDaoImp implements PersonDao{

	public Person savePerson(int eid, Person Person) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Encounter encounter= emEntityManager.find(Encounter.class, eid);
		if(encounter!=null) {
			etEntityTransaction.begin();
			emEntityManager.persist(Person);
			etEntityTransaction.commit();
		return Person;}
		else
		{
			return null;
		}
	}

	public Person getPersonById(int pid) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Person person=emEntityManager.find(Person.class, pid);
		return person;
	}

	public boolean deletePersonById(int pid) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
	Person person=emEntityManager.find(Person.class, pid);
		if(person!=null) {
			etEntityTransaction.begin();
			emEntityManager.remove(person);
			etEntityTransaction.commit();
			return true;
		}
		else {
		return false;}
	}

	public Person updatePersonById(int pid, Person person) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Person person1=emEntityManager.find(Person.class, pid);
		if(person1!=null) {
			etEntityTransaction.begin();
			emEntityManager.remove(person1);
			etEntityTransaction.commit();
			return person1;}
		else {
		return null;}
	}

	public List<Person> getAllPerson() {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		Query query=emEntityManager.createNamedQuery("select p from Person p");
		List<Person> persons=query.getResultList();
		return persons;
	}

	public List<Person> getPersonByGender(String gender) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Query query=emEntityManager.createNamedQuery("select p from Person p where p.gender=?1");
		query.setParameter(1, "gender");
		List<Person> persons=query.getResultList();
		return persons;
	}

	public List<Person> getPersonByPhno(long phno) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Query query=emEntityManager.createNamedQuery("select p from Person p where p.phno=?1");
		query.setParameter(1, phno);
		List<Person> persons=query.getResultList();
		return persons;
	}

	public List<Person> getPersonByAge(int age) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Query query=emEntityManager.createNamedQuery("select p from Person p where p.age=?1");
		query.setParameter(1, age);
		List<Person> persons=query.getResultList();
		return persons;
	}

}
