package com.ty.Hospital.dao;

import com.ty.Hospital.dto.Hospital;

public interface HospitalDao {

	public Hospital SaveHospital(Hospital hospital);

	public Hospital getHospitalById(int hid);

	public boolean deleteHospitalById(int hid);

	public Hospital updateHospitalById(int hid,Hospital hospital);
}
