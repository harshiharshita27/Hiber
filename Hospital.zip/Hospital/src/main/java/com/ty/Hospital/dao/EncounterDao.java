package com.ty.Hospital.dao;

import java.util.List;

import com.ty.Hospital.dto.Encounter;

public interface EncounterDao {

	public Encounter saveEncounter(int bid,Encounter encounter);

	public Encounter getEncounterById(int eid);

	public boolean deleteEncounterById(int eid);

	public Encounter updateEncounterById(int eid,Encounter encounter);
	
	public List<Encounter> getAllEncounter();
}
