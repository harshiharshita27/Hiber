package com.ty.Hospital.Service;

import java.util.List;

import com.ty.Hospital.dao.Imp.UserDaoImp;
import com.ty.Hospital.dto.User;

public class UserService {
	public void saveUser(User user) {
		UserDaoImp userDaoImp = new UserDaoImp();
		User user1 = userDaoImp.saveUser(user);
		if(user1!=null) {
			System.out.println("save data");
		}
		
		else {
			System.out.println("not save data");
		}
	}
	public User getUserById(int uid) {
		UserDaoImp userDaoImp = new UserDaoImp();
		User user1 = userDaoImp.getUserById(uid);
		if(user1!=null) {
			return user1;
		}
		else {
			return null;
		}
	}
	public void deleteUserById(int uid) {
		UserDaoImp userDaoImp = new UserDaoImp();
		boolean flag = userDaoImp.deleteUserById(uid);
		if(flag){
			System.out.println("delete data");
		}
		else {
			System.out.println("not delete");
		}
	}
	
	public User updateUserById(int uid, User user) {
		UserDaoImp userDaoImp = new UserDaoImp();
		User user1 = userDaoImp.updateUserById(uid, user);
		if(user1!=null) {
			return user1;
		}
		else {
			return null;
		}
	}
	public List<User> getAllUser(){
		UserDaoImp userDaoImp = new UserDaoImp();
		List<User> users=userDaoImp.getAllUser();
		if(users.size()>0) {
			return users;
		}
		else
			return null;
	}
	public User getUserByName(String name) {
		UserDaoImp userDaoImp = new UserDaoImp();
		User users= userDaoImp.getUserByName(name);
		return users;	
	}
	
	public User getUserByRole(String role) {
		UserDaoImp userDaoImp = new UserDaoImp();
		User users= userDaoImp.getUserByRole(role);
		return users;	
	}	
}
