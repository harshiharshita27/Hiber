package com.ty.Hospital.Controller;

import com.ty.Hospital.Service.BranchService;
import com.ty.Hospital.Service.HospitalService;
import com.ty.Hospital.dto.Branch;
import com.ty.Hospital.dto.Hospital;

public class SaveBranch {

	public static void main(String[] args) {
		Branch branch = new Branch();
		BranchService service = new BranchService();
		branch.setName("Bilichodu");
		branch.setPhno(9900697161l);
		branch.setEmail("pinky@123.com");
		service.saveBranch(2, branch);
		
		Branch branch1 = new Branch();
		BranchService service1 = new BranchService();
		branch1.setName("jagaluru");
		branch1.setPhno(99636337161l);
		branch1.setEmail("harshi@123.com");
		service1.saveBranch(3, branch1);
		
		Branch branch2 = new Branch();
		BranchService service2 = new BranchService();
		branch2.setName("davanagere");
		branch2.setPhno(96564755324l);
		branch2.setEmail("harsh@123.com");
		service2.saveBranch(4, branch2);

		Branch branch3 = new Branch();
		BranchService service3= new BranchService();
		branch3.setName("Bangaloru");
		branch3.setPhno(6363371614l);
		branch3.setEmail("harsh@123.com");
		service3.saveBranch(5, branch3);

	}

}
