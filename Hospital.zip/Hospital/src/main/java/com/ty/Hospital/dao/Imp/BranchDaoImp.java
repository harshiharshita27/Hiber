package com.ty.Hospital.dao.Imp;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.ty.Hospital.dao.BranchDao;
import com.ty.Hospital.dto.Branch;
import com.ty.Hospital.dto.Hospital;

public class BranchDaoImp implements BranchDao {

	public Branch saveBranch(int hid, Branch branch) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Hospital hospital=emEntityManager.find(Hospital.class, hid);
		if(hospital!=null) {
			etEntityTransaction.begin();
			emEntityManager.persist(branch);
			etEntityTransaction.commit();
			return branch;
		}
		else {
		return null;}
	}

	public Branch getBranchById(int bid) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Branch branch = emEntityManager.find(Branch.class, bid);
			
		return branch;
	}

	public boolean deleteBranchById(int bid) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Branch branch = emEntityManager.find(Branch.class, bid);
		if(branch!=null) {
			etEntityTransaction.begin();
			emEntityManager.remove(branch);
			etEntityTransaction.commit();
			return true;
		}
		else {
		return false;}
	}

	public Branch updateBranchById(int bid, Branch branch) {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		EntityTransaction etEntityTransaction=emEntityManager.getTransaction();
		Branch branch1 = emEntityManager.find(Branch.class, bid);
		if(branch1!=null) {
			branch1.setName(branch.getName());
			branch1.setPhno(branch.getPhno());
			branch1.setEmail(branch.getEmail());
			etEntityTransaction.begin();
			emEntityManager.merge(branch);
			return branch1;
		}
		else
		{
		return null;}
	}

	public List<Branch> getAllBranch() {
		EntityManagerFactory emfEntityManagerFactory=Persistence.createEntityManagerFactory("bharath");
		EntityManager emEntityManager=emfEntityManagerFactory.createEntityManager();
		Query query =emEntityManager.createNamedQuery("select b from Branch b");
		List<Branch> branchs=query.getResultList();
		return branchs;
	}

	

}
